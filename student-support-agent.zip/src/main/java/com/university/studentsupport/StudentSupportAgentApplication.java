package com.university.studentsupport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSupportAgentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSupportAgentApplication.class, args);
	}

}
